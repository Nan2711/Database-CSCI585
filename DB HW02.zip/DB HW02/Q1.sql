/*
http://sqlfiddle.com/
MySQL 5.6

use table.sql to build schema
*/

    
/*Q1 
Find the sponsor who has sponsored the highest amount in YouTube. Display the sponsor's name, phone number and the total amount sponsored.
Below query groups sponser id and performs summation of amount.
*/


select SponserName, SponserPhone, max(sum_amount) AS Highest_Amount FROM
(
SELECT s.SponserName, s.SponserPhone, sum(vs.amount) as sum_amount
 FROM ( ( Sponser s INNER JOIN VideoSponser vs ON (s.SponserID = vs.sponser_id) ) 
INNER JOIN video v ON v.videoID = vs.videoID ) group by vs.sponser_id 
ORDER BY sum_amount DESC
) AS T;
