/*
http://sqlfiddle.com/
MySQL 5.6
use table.sql to build schema
*/

/*Q3
Find unique user with the total number of paid subscribers greater than 100 for their channel created on 01.01.2023. DIsplay the username, email, channel name and the subscriber count.

Below query displays the channel created on jan 01 2023 and the total number paid subscribers who are greater than 100. 
*/  
select User.UserName, User.UserEmail, Channel.ChannelName, 
  Channel.subscriptionCount AS subscriptionCount
  FROM Channel  inner join Subscription  ON (Channel.ChannelName = Subscription.ChannelName)  
  inner join VideoConsumers  ON (Subscription.consumerID = VideoConsumers.consumerID) 
inner join User  ON (User.UserID = VideoConsumers.user_id)
  WHERE DATE(Channel.CreatedDateTime) = '2023.01.01' AND Subscription.subscription_type='paid' group by Subscription.ChannelName; 
  HAVING Channel.subscriptionCount > 100;
   