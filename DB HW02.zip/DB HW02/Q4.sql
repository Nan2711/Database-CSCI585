/*
http://sqlfiddle.com/
MySQL 5.6
use table.sql to build schema
*/
  
    /*Q4
Find the avergage sentiment score for each keyword category. Display the keyword name along with average score such that the highest score is displayed first.

 AVG function is used to find the average sentiment score.
    */
select avg(sentiment) AS AverageSentimentScore, InformationalVideo.keywords from InformationalVideo   
  inner join video  
  ON (video.videoID = InformationalVideo.videoID) inner join comment  ON (comment.videoID = video.videoID) 
  group by InformationalVideo.keywords order by AverageSentimentScore DESC;


