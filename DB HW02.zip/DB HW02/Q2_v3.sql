/*
http://sqlfiddle.com/
MySQL 5.6
use table.sql to build schema
*/
  
/*Q2_3
Without using inner join, the ratio of likes to views can be found.
*/
select VideoMetadata.title, Channel.ChannelName, 
count(Comment.likeCount)/(select count(videoID) from InformationalVideo where lower(keywords) != "marvel entertainment")  
AS ratio from video,  VideoMetadata, InformationalVideo,  Channel,  Comment  
WHERE (video.metadata = VideoMetadata.MetaID) AND 
 (InformationalVideo.videoID = video.videoID) AND (Channel.ChannelName = video.ChannelName) 
AND (Comment.videoID = video.videoID)
AND lower(InformationalVideo.keywords) LIKE '%marvel entertainment%' 
 group by Comment.videoID order by VideoMetadata.title ASC;
