/*
http://sqlfiddle.com/
MySQL 5.6
use table.sql to build schema
*/

	

/*Q6
Find all the content creators living in the US who have consistently posted at least 1 video each week of the last month. 

LIKE is used to check whther address has US.
YEAR() and month() function, dates and months can be extracted and content creators who have consistently posted at least 1 video each week of the last month is calculated.
   */


SELECT user.UserName, channel.ChannelName, Channel.subscriptionCount AS Total_Subscription_Count 
FROM user
INNER JOIN VideoCreators ON user.UserID = VideoCreators.CreatorID
INNER JOIN channel ON channel.OwnerID = VideoCreators.user_id
INNER JOIN subscription ON subscription.ChannelName = channel.ChannelName
INNER JOIN video ON video.ChannelName = channel.ChannelName
WHERE user.UserAddress LIKE '%US%' 
  AND channel.ChannelName IN (
    SELECT ChannelName FROM video 
    WHERE YEAR(UploadedDate) = YEAR(CURDATE()) 
      AND MONTH(UploadedDate) = MONTH(CURDATE()) - 1 
      AND DAY(UploadedDate) BETWEEN 1 AND 7 
      OR DAY(UploadedDate) BETWEEN 8 AND 15
      OR DAY(UploadedDate) BETWEEN 16 AND 22
      OR DAY(UploadedDate) BETWEEN 23 AND 31
  )
GROUP BY user.UserName, channel.ChannelName;

    