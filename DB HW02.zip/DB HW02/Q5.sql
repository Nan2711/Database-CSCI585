/*
http://sqlfiddle.com/
MySQL 5.6
use table.sql to build schema
*/

	
/*Q5
Find the minimum and maximum age of viewers who watched the most commented on video on Taylor Swift's channel. Display the video title, minimum age and the maximum age.

   min() function is used to calculate the minimum age of viewer and max() function is used to calculate the maximum age of viewers.
    */
  select vid_met_2.title, min(DATE_FORMAT(FROM_DAYS(DATEDIFF(now(),user_2.DOB)), '%Y')+0) AS Minimum_Age, 
max(DATE_FORMAT(FROM_DAYS(DATEDIFF(now(),user_2.DOB)), '%Y')+0) AS Maximum_Age 
 from user user_2,   comment comm_2, video vid_2, VideoMetadata vid_met_2 
WHERE  (comm_2.user_id = user_2.UserID) AND 
(vid_2.videoID = comm_2.videoID) AND (vid_2.metadata = vid_met_2.MetaID) AND comm_2.videoID IN
 (
select videoID FROM (
select videoID, max(comment_ID_count)  FROM (
select co.videoID, count(co.comment_id) AS comment_ID_count 
 from user u 
inner join VideoCreators vc ON (u.UserID = vc.user_id)
 inner join channel c ON (c.OwnerID = vc.user_id) inner join video v ON
 (v.ChannelName = c.ChannelName) inner join  VideoMetadata vm ON (vm.MetaID = v.metadata)
 inner join comment co ON (co.videoID = v.videoID) 
 INNER JOIN user u1 ON (co.user_id = u1.UserID)
 WHERE u.UserName = 'Taylor Swift' group by co.videoID order by co.videoID DESC
) AS T) AS U
);  
   
