/*
http://sqlfiddle.com/
MySQL 5.6
use table.sql to build schema
*/
 
/*Q2_2
Find the  ratio of likes to views of each video belonging to any of the channels owned by users having the word "Marvel Entertainment" in them. Display the video title, channel name and the ratio in the ascending order of the title. 
Comment table can be used to find the ratio of likes to views.
*/
select VideoMetadata.title, channel.ChannelName, 
count(comment.likeCount)/(select count(videoID) from InformationalVideo where lower(keywords) != "marvel entertainment")  
AS ratio from video  inner join VideoMetadata  
ON (video.metadata = VideoMetadata.MetaID) inner join InformationalVideo  
ON (InformationalVideo.videoID = video.videoID) inner join Channel ON (channel.ChannelName = video.ChannelName) 
inner join Comment  ON (Comment.videoID = video.videoID)
WHERE lower(InformationalVideo.keywords) = 'marvel entertainment'  group by comment.videoID order by VideoMetadata.title ASC;

 