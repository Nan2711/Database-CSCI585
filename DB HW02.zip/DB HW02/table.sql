/*
http://sqlfiddle.com/
MySQL 5.6
*/

/* Use this file (below table insertion and deletion commands) for all the 6 questions*/
/* Please dont copy these comments directly copy from start of code otherwise it will exceed the 8000 limit of sql fiddle*/
create table User (UserID int primary key, UserName varchar(30), UserEmail varchar(30),  UserAddress varchar(100), DOB date);

create table VideoCreators (CreatorID INT primary key, user_id int, foreign key(user_id) references User(UserID) );

create table VideoConsumers (consumerID INT primary key, user_id int , 
foreign key(user_id) references User(UserID) );

create table VideoMetadata(MetaID int primary key, url varchar(80),  title varchar(80), thumbnails varchar(40), category varchar(60), 
  duration int, description varchar(150), UploadDateTime timestamp);


create table Channel(ChannelName varchar(100) primary key, CreatedDateTime timestamp, 
OwnerID int, subscriptionCount INT, foreign key(OwnerID) references VideoCreators(CreatorID) );

create table video (videoID int primary key, ChannelName varchar(100), metadata int, UploadedDate DATE, 
  foreign key(ChannelName) references Channel (ChannelName), 
  foreign key(metadata) references VideoMetadata(MetaID) );

create table Sponser (SponserID INT primary key, SponserName varchar(30), SponserPhone varchar(15), address varchar(100) );


create table InformationalVideo (keywords varchar(100), videoID INT, 
primary key(keywords, videoID),  foreign key(videoID) references video (videoID) );

create table EntertainmentVideo (tags varchar(100), videoID INT, primary key(tags, videoID),  foreign key(videoID) references video (videoID) );

create table VideoSponser (videoID int, sponser_id int, amount int, foreign key(videoID) references video(videoID), 
foreign key(sponser_id) references Sponser (SponserID)
 );


create table Revenue (RevenueID INT primary key, videoID INT, likeCount int, dislike int, 
  sharecount int, commentCount int, foreign key(videoID) references video (videoID) );


create table comment (comment_id INT primary key, videoID int, user_id int, commentText varchar(100),
  likeCount int, sentiment int, commentedDateTime timestamp, foreign key(videoID) references video (videoID), 
foreign key(user_id) references User (UserID)
);

create table Subscription (consumerID INT, ChannelName varchar(100), subscription_type varchar(30), 
foreign key(consumerID) references VideoConsumers (consumerID), 
foreign key(ChannelName) references Channel (ChannelName), 
primary key(consumerID, ChannelName)
 );



insert into User values (1, 'Mia', 'mia24@gmail.com',  '4233 Jefferson Street, Norfolk, Virginia, 02, US', '1998-03-02');
insert into User values (2, 'Sophia', 'sopia22@gmail.com',  '4223 Jefferson Street, Norfolk, Virginia, 202, US', '1999-02-14');
insert into User values (3, 'Charlotte', 'charlotte12@gmail.com',  '2263 Jefferson Street, Norfolk, Virginia, 302, US', '2002-02-26');
insert into User values (4, 'Taylor Swift', 'taylor22@gmail.com',  '5263 Jefferson Street, Norfolk, Virginia, 302, US', '1995-01-16');
insert into User values (5, 'Emma', 'emma22@gmail.com',  '6663 Jefferson Street, Norfolk, Virginia, 23302, US', '1990-01-02');


insert into VideoCreators values (1, 1);
insert into VideoCreators values (2, 2);
insert into VideoCreators values (3, 3);
insert into VideoCreators values (4, 4);
insert into VideoCreators values (5, 5);

insert into VideoConsumers values (1, 1);
insert into VideoConsumers values (2, 2);
insert into VideoConsumers values (3, 3);
insert into VideoConsumers values (4, 4);
insert into VideoConsumers values (5, 5);


insert into VideoMetadata values (1, 'https://mia.com', 'Mia Video', 'mia.png', 'video', 20, 'Mia Video',  '2023-02-02 01:01:01');
insert into VideoMetadata values (2, 'https://sophia.com', 'Andrew Video', 'andrew.png', 'video', 20, 'Sophia Video',  '2023-01-18 02:02:01');
insert into VideoMetadata values (3, 'https://charlotte.com', 'Atkinson Video', 'atkinson.png', 'video', 20, 'Charlotee Video',  '2023-11-10 03:03:03');
insert into VideoMetadata values (4, 'https://taylor_swift.com', 'Taylor Swift Video', 'taylor.png', 'video', 20, 'Taylor Swift Video',  '2023-10-08 03:00:01');
insert into VideoMetadata values (5, 'https://emma.com', 'Bailey Video', 'bailey.png', 'video', 20, 'Emma Video',  '2023-01-01 05:05:01');


insert into Channel values ('Mia Channel', '2023.01.01 02:02:01', 1, 120);
insert into Channel values ('Sophia Channel', '2023.01.01 02:02:01', 2, 124);
insert into Channel values ('Charlotte Channel', '2023-02-02 04:04:04', 3, 1);
insert into Channel values ('Taylor Swift Channel', '2023-02-02 03:03:03', 4, 1);
insert into Channel values ('Emma Channel', '2023.01.01 02:02:01', 5, 101);


    
 insert into video values (1, 'Mia Channel', 1, '2023-02-03');
insert into video values (2, 'Taylor Swift Channel', 4, '2023-05-12');
insert into video values (3, 'Taylor Swift Channel', 4, '2023-02-22');
insert into video values (4, 'Sophia Channel', 3, '2023-01-01');
insert into video values (6, 'Sophia Channel', 2, '2023-03-13');
insert into video values (7, 'Emma Channel', 5, '2023-02-14');
insert into video values (8, 'Emma Channel', 2, '2023-01-22');


insert into Sponser values (1, 'Olivia', '987 748 3838', '4263 Jefferson Street, Norfolk, Virginia, 23502, US');
insert into Sponser values (2, 'Emma', '383 474 9283', '4260 Jefferson Street, Norfolk, Virginia, 23501, US');
insert into Sponser values (3, 'Amelia', '999 333 4444', '4262 Jefferson Street, Norfolk, Virginia, 23503, US');
insert into Sponser values (4, 'Ava', '999 333 4444', '4261 Jefferson Street, Norfolk, Virginia, 23504, US');
insert into Sponser values (5, 'Isabella', '999 333 4444', '4264 Jefferson Street, Norfolk, Virginia, 23505, US');



insert into InformationalVideo values ('Marvel Entertainment', 1);
insert into InformationalVideo values ('Sentiment', 2);
insert into InformationalVideo values ('Comedy Entertainment', 3);
insert into InformationalVideo values ('Marvel Entertainment', 4);



insert into EntertainmentVideo values ('Anderson Channel', 1);
insert into EntertainmentVideo values ( 'Taylor Swift Channel', 2);
insert into EntertainmentVideo values ('Taylor Swift Channel', 3);
insert into EntertainmentVideo values ( 'Atkinson Channel', 4);
insert into EntertainmentVideo values ('Andrew Channel', 6);
insert into EntertainmentVideo values ( 'Bailey Channel', 7);
insert into EntertainmentVideo values ( 'Andrew Channel', 8);



insert into VideoSponser values (1, 1, 1000);
insert into VideoSponser values (2, 1, 1000);
insert into VideoSponser values (3, 2, 1000);
insert into VideoSponser values (4, 3, 2000);
insert into VideoSponser values (6, 2, 1000);
insert into VideoSponser values (7, 3, 2000);
insert into VideoSponser values (8, 2, 4000);


insert into Revenue Values (1, 1, 1, 0, 1, 1);
insert into Revenue Values (2, 2, 1, 0, 1, 1);
insert into Revenue Values (3, 3, 1, 0, 1, 1);
insert into Revenue Values (4, 4, 1, 0, 1, 1);
insert into Revenue Values (6, 6, 1, 0, 1, 1);
insert into Revenue Values (7, 7, 1, 0, 1, 1);
insert into Revenue Values (8, 8, 1, 0, 1, 1);



insert into comment values (1, 1, 1, 'Good movie', 1, 50, '2023-02-02 00:01:01');
insert into comment values (2, 2, 2, 'Good movie', 1, 50, '2022-03-03 02:01:01');
insert into comment values (3, 3, 3, 'Good movie', 1, 80, '2022-01-12 03:02:01');
insert into comment values (4, 4, 1, 'Good movie', 1, 30, '2023-02-05 03:03:01');
insert into comment values (6, 6, 3, 'Good movie', 1, 90, '2023-01-11 03:05:01');
insert into comment values (7, 7, 3, 'Good movie', 1, 80, '2023-01-12 03:06:01');
insert into comment values (8, 8, 4, 'Good movie', 1, 80, '2023-01-14 03:07:01');


insert into Subscription VALUES (1, 'Mia Channel', 'paid');
insert into Subscription VALUES (2, 'Sophia Channel', 'paid');
insert into Subscription VALUES (3, 'Charlotte Channel', 'free');
insert into Subscription VALUES (1, 'Taylor Swift Channel', 'free');