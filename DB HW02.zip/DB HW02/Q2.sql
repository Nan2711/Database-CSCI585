/*
http://sqlfiddle.com/
MySQL 5.6
use table.sql to build schema
*/

/*Q2
Find the  ratio of likes to views of each video belonging to any of the channels owned by users having the word "Marvel Entertainment" in them. Display the video title, channel name and the ratio in the ascending order of the title. 
The ratio is calculated by dividing total like count of marvel entertainment divided by total number videos that does not have keyword marvel entertainment.
*/

select VideoMetadata.title, Channel.ChannelName, 
(Revenue.likeCount)/
(select count(videoID) from InformationalVideo where lower(keywords) != "marvel entertainment") 
AS ratio
from video  inner join VideoMetadata 
ON (video.metadata = VideoMetadata.MetaID) inner join InformationalVideo  
ON (InformationalVideo.videoID = video.videoID) inner join Channel  ON (Channel.ChannelName = video.ChannelName) 
inner join Revenue  ON (Revenue.videoID = video.videoID)
WHERE lower(InformationalVideo.keywords) = 'marvel entertainment' order by VideoMetadata.title ASC;

