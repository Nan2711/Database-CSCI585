Name: Nandila Bhattacharjee
Course Code: CSCI585
Homework#1

DESIGN DOCUMENT - EXTENDED ENTITY-RELATIONSHIP DIAGRAM FOR YOUTUBE


Crow's foot notation is used to construct an EER diagram.
Dashed (---) lines represent a strong relationship between the entities.
Solid (‑‑‑‑‑‑‑‑‑‑) lines represent weak relationship between the entities.
PK represents primary key and FK represents foreign key.
Many to many relationship entities are connected using bridge entity.
Attributes highlighted in bold cannot be NULL and are required attributes.

Entity name: User
Attributes: 
Unique_ID - It uniquely identifies an user.
name - User's name
email - User's email
age - User's age
address - User's address
date of birth - User's date of birth

Entity name: Video Consumers
Attributes: 
Consumer_ID: It uniquely identifies a consumer.
Unique ID - This foreign key refers user table primary key.

Entity name: Video Creators
Attributes: 
Creator_ID: It uniquely identifies a creator.
Unique ID - This foreign key refers user table primary key.



Entity name: Subscription
Attributes: 
Consumer_ID - It refers Consumer's id.
Channel_Name - It refers Channel's name.
Subscription Type - It stores the subscription type either paid or free.

Entity name: Channel
Attributes: 
Channel_Name - It uniquely identifies a channel.
Creator_ID - It refers creator's ID.
owner - Channel's owner
subscription count - Total subscription count
CreatedDateTime - Channel's created date time.

Entity name: Revenue
Attributes: 
Revenue_ID - It uniquely identifies a revenue.
Video_ID - It refers the id of a video.
Likes - Total like count
Dislikes - Total dislike count
ViewCount - Total view count
ShareCount - Total share count
CommentCount - Total comment count

Entity name: Comment
Attributes: 
Comment_ID - It uniquely identifies a comment.
Video_ID - It refers the id of video
Unique_ID - It refers ID of user who has posted comment.
Comment Text - It stores the comment text value.
Likes - It stores the like count value.
sentiment - It stores whether the video is sentiment or not.
CommentedDateTime - It stores commented time.

Entity name: Video
Attributes: 
Video_ID - It uniquely identifies a video.
Channel_Name - Name of the video.
Uploader_ID - It refers the ID of the user who uploads the video.
length - Length of the video.

Entity name: Video_metadata
Attributes: 
Video_ID - It uniquely identifies a video.
URL - URL of the video.
Title - Title of the video.
Thumbnails - Thumbnails details of the video.
Category - Category of the video.
Duration - Duration of the video.
Description - Description of the video.
Upload Date - Video uploaded date.
Upload Time - Video uploaded time.

Entity name: Informational Video
Attributes: 
Keywords - Informational video is identified by keywords.
Video_ID - It refers the ID of video.

Entity name: Entertainment Video
Attributes: 
Tags - Entertainment video is identified by tags.
Video_ID - It refers the ID of video.

Entity name: Sponser
Attributes: 
Sponser_ID - It uniquely identifies the sponser.
Video_ID - Video's Identification Number .It refers the video table primary key.
name - Name of the sponser.
phone - Sponser's phone number.
address - Sponser's address.
amount - Sponser's amount.
	
Entity name: Sponser
Attributes: 
Video_ID - It refers the ID of the video.
Sponser _ID - It refers the ID of the sponser.
amount - Amount sponsered for the video.






Relationship
A user can be a video consumer or video creator or both video consumer as well as video creator.

A video can either be an informational video or an entertainment video but not both.

Video Consumer --- subscribes --- Subscription
A video consumer can subscribe one or many channel.

Channel --- subscribed by --- Subscription
A channel can be subscribed by one or many consumer.


Video Creator --- creates --- Channel
A video creator can create any number of channels.
A channel belongs to one creator alone

Channel --- has --- Video
A channel can have one or any number of video.
A video belongs to one channel.

Video --- earns --- Revenue
A video can have one or any number of revenue.
Revenue belongs to one video.

Video --- Commented for --- Comment
A video can have any number of comments.
A comment belongs to one video.

Video --- sponsered by --- Video_Sponser
A video can have any number of sponser.


Sponser --- sponseres --- Video_Sponser
A sponser can sponser any number of videos.

	


